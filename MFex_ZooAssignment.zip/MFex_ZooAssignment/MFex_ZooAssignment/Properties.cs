﻿using System;
namespace MFex_ZooAssignment
{
    public static class Properties
    {
        public static string PATHCSV = "/Users/jevu/Projects/MFex_ZooAssignment/MFex_ZooAssignment/Resources/Animals.csv";
        public static string PATHTXT = "/Users/jevu/Projects/MFex_ZooAssignment/MFex_ZooAssignment/Resources/Prices.txt";
        public static string PATHXML = "/Users/jevu/Projects/MFex_ZooAssignment/MFex_ZooAssignment/Resources/Zoo.xml";

        public static string EXCMSG = "Error";


        public static char PERCENTAGE = '%';
        public static char COMMASEPARATED = ';';
        public static char EQUAL = '=';

        public static string MEAT = "Meat";

        public static string SUCMSG = "Total Food Price For a Day for Animals in Zoo: ";
    }
}
